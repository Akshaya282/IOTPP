const connectionEl = document.getElementById("connection");
const brightnessInput = document.getElementById("brightness");
const brightnessValue = document.getElementById("brightness-value");

function setConnection(online) {
  connectionEl.textContent = online ? "Connected to Raspberry Pi" : "Cannot reach Raspberry Pi";
  connectionEl.className = online ? "status online" : "status offline";
}

async function sendJson(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Request failed");
  return result;
}

async function loadState() {
  try {
    const response = await fetch("/api/state");
    if (!response.ok) throw new Error("Could not read current state");
    const state = await response.json();

    state.relays.forEach((isOn, index) => {
      const channel = index + 1;
      const toggle = document.querySelector(`[data-channel="${channel}"]`);
      toggle.checked = isOn;
      document.getElementById(`relay-state-${channel}`).textContent = isOn ? "ON" : "OFF";
    });

    brightnessInput.value = state.brightness;
    brightnessValue.textContent = state.brightness;
    setConnection(true);
  } catch (error) {
    setConnection(false);
    console.error(error);
  }
}

document.querySelectorAll(".relay-toggle").forEach((toggle) => {
  toggle.addEventListener("change", async () => {
    const channel = Number(toggle.dataset.channel);
    const desiredState = toggle.checked;
    toggle.disabled = true;
    try {
      const result = await sendJson(`/api/relay/${channel}`, { state: desiredState });
      document.getElementById(`relay-state-${channel}`).textContent = result.state ? "ON" : "OFF";
      setConnection(true);
    } catch (error) {
      toggle.checked = !desiredState;
      alert(`Relay ${channel}: ${error.message}`);
      setConnection(false);
    } finally {
      toggle.disabled = false;
    }
  });
});

let brightnessTimer;
brightnessInput.addEventListener("input", () => {
  brightnessValue.textContent = brightnessInput.value;
  clearTimeout(brightnessTimer);
  brightnessTimer = setTimeout(async () => {
    try {
      await sendJson("/api/led", { brightness: Number(brightnessInput.value) });
      setConnection(true);
    } catch (error) {
      alert(`LED control: ${error.message}`);
      setConnection(false);
    }
  }, 100);
});

loadState();
